import{a as e,b as c,o as n}from"./entry.68c1c929.js";const o={};function r(t,a){return n(),c("h1",null,"Home")}const _=e(o,[["render",r]]);export{_ as default};
